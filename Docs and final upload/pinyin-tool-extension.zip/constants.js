(function(){const i=document.createElement("link").relList;if(i&&i.supports&&i.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))n(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const o of t.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function r(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function n(e){if(e.ep)return;e.ep=!0;const t=r(e);fetch(e.href,t)}})();const l=/[\u4e00-\u9fff\u3400-\u4dbf]/,s={openai:{baseUrl:"https://api.openai.com/v1",defaultModel:"gpt-4o-mini",apiStyle:"openai",requiresApiKey:!0,models:["gpt-4o-mini","gpt-4o","gpt-4.1-nano"]},gemini:{baseUrl:"https://generativelanguage.googleapis.com",defaultModel:"gemini-2.5-flash",apiStyle:"gemini",requiresApiKey:!0,models:["gemini-2.5-flash","gemini-2.5-flash-lite","gemini-2.5-pro"]},ollama:{baseUrl:"http://localhost:11434/v1",defaultModel:"qwen2.5:7b",apiStyle:"openai",requiresApiKey:!1,models:["qwen2.5:7b","llama3:8b","mistral:7b","gemma2:9b"]},custom:{baseUrl:"",defaultModel:"",apiStyle:"openai",requiresApiKey:!1,models:[]}},c={provider:"openai",apiKey:"",baseUrl:s.openai.baseUrl,model:s.openai.defaultModel,pinyinStyle:"toneMarks",fontSize:16,theme:"auto",llmEnabled:!0,ttsEnabled:!0},d=10080*60*1e3,u=1e4,p=.4,f=1e4,m=2048,h=0,g=500,E=`You are a Chinese language assistant integrated into a browser extension.
Given Chinese text and its surrounding context, you must:
1. Segment the text into individual words (not characters).
2. Provide the correct pinyin for each word, using tone marks.
   For polyphonic characters, use the surrounding context to choose the correct reading.
3. Provide a concise English definition for each word as it is used in this context.
4. Provide a natural English translation of the full text.

Respond ONLY with valid JSON in this exact format:
{
  "words": [
    { "chars": "<characters>", "pinyin": "<pinyin with tone marks>", "definition": "<contextual English definition>" }
  ],
  "translation": "<full English translation>"
}`;export{d as C,c as D,p as F,f as L,g as M,s as P,E as S,l as a,h as b,m as c,u as d};
